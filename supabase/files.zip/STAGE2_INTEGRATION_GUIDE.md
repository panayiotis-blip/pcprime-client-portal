# Cyprus Tax App — Stage 2 Complete

## File: `CyprusTaxApp.jsx`

A complete React application providing **two integrated modes** for Cyprus personal tax work:

1. **Quick Calculator** — Fast estimates with comparison mode
2. **Full Tax Return (TD1)** — Comprehensive TD1-style tax return preparation

Both modes share the same validated calculation engine.

---

## What's New in Stage 2

### **Tax Return Form (TD1-style)**

Mirrors the official Cyprus TD1 form structure with **15 numbered Parts**:

| Part | Title | Key Features |
|------|-------|--------------|
| 1 | Personal Information | TIC, ID, name (Latin & Greek), address, IBAN |
| 2 | GHS / GeSY Information | Exemption status, S1/A1 holder details |
| 3 | Tax Residency | 183/60-day rule, domicile status, first employment |
| 4 | Employment Income | **Multiple employers** with codes 1-9 |
| 5 | Pensions | Cyprus (SIS/Treasury/Employer) + Foreign + Widow's |
| 6 | Rental Income | **Multiple properties** with per-property breakdown |
| 7 | Self-Employment | **Multiple businesses** with SI categories |
| 8 | Investment Income | **Multiple dividend & interest sources** |
| 9 | Other Income | Royalties (IP Box), goodwill, crypto, AIF, severance |
| 10 | Capital Gains | Display-only (shares 0%, property separate CGT) |
| 11 | Allowable Deductions | Comprehensive (personal + self-employed) |
| 12 | 2026 Family Allowances | Children, students, mortgage/rent, green |
| 13 | Tax Already Paid | PAYE (auto-totaled) + provisional + foreign credits |
| 14 | Computation Summary | Real-time live computation panel |
| 15 | Document Checklist | **Auto-generated** based on entries |

### **Key Architectural Improvements**

✓ **Array-based income sources** — Add unlimited employers, rentals, dividend sources, etc.
✓ **Auto-generated document checklist** — Tells client what to upload to portal
✓ **Live computation panel** — Updates as you type
✓ **Status workflow** — Draft / Pending Review / Reviewed / Filed
✓ **Reference numbers** — Auto-generated PCC-TR-XXXXXXXX
✓ **Internal notes** — Private notes that don't appear on filed return
✓ **Completion indicators** — Visual ● / ○ / ✓ for each Part
✓ **Reuses validated calculation engine** from Stage 1

### **Mode Toggle**

A persistent top bar lets you switch between modes:
- **Quick Calculator** — For "what if" scenarios and ballpark estimates
- **Full Tax Return** — For preparing actual TD1 returns

---

## Quick Integration

```bash
npm install lucide-react
```

```jsx
import CyprusTaxApp from './components/CyprusTaxApp';

function App() {
  return <CyprusTaxApp />;
}
```

That's it. **One component, both modes.**

---

## File Structure (Single File, ~3,327 lines)

```
CyprusTaxApp.jsx
├── Imports
├── TAX_YEARS constant (2025 + 2026)
├── COLORS constant
├── FIRM_LOGO (base64)
├── Helper functions (fmt, etc.)
├── Stable sub-components (Section, ResultRow, InputRow)
├── ComputationPanel component
│
├── ============ STAGE 1: CyprusTaxCalculatorView ============
│   ├── Quick calculator (existing functionality preserved)
│   └── PDF/CSV/Email export
│
├── ============ STAGE 2: TAX RETURN FORM ============
│   ├── PartHeader, FieldRow, SelectRow, ArrayItemCard helpers
│   ├── CyprusTaxReturnForm component
│   ├── 15 numbered Parts
│   ├── Live computation panel
│   ├── Document checklist generator
│   └── Internal notes
│
└── ============ MAIN APP WRAPPER ============
    └── CyprusTaxApp (default export)
        └── Mode toggle: Calculator vs Tax Return
```

---

## Calculation Coverage

The form computes:

**Income Aggregation:**
- Sums all employments → applies 50%/20%/first-employment exemptions
- 90-day rule pro-rata exemption (when code 4 used)
- Sums all rentals → 20% W&T + interest + maintenance + capital allowances
- Sums all self-employments (gross - expenses - capital allowances)
- Sums all dividends (with SDC/GHS at source tracking)
- Sums all interest (with SDC/GHS at source tracking)
- Cyprus + Foreign pensions with election options

**Tax Calculations:**
- Progressive Income Tax (PIT) — band-by-band breakdown
- Special Defence Contribution (SDC) — only for Cyprus-domiciled residents
- Crypto disposals — 8% flat
- AIF carried interest — 8% flat with €10,000 minimum
- Severance — 20% over €200,000
- Foreign pension — 5% flat election option
- Widow's pension — 5% flat election (over €3,420)

**Deductions:**
- All standard items (donations, subscriptions, life insurance, pension, medical)
- 1/5 (20%) cap on optional deductions correctly applied
- Self-employed (capital allowances, bad debts)
- Disability expenses
- Loss carry-forward (5/7 years depending on year)
- Foreign tax credit (capped at PIT)

**2026 Family Allowances:**
- Children: €1,000 / €1,250 / €1,500 per dependant
- Students up to age 24
- Mortgage interest OR rent (max €2,000)
- Green investment (max €1,000)
- Home insurance (max €500)
- Family income threshold check

**Final Output:**
- Total tax liability
- PAYE + provisional tax already paid
- **Balance Due** or **Refund Due**
- Effective tax rate
- Net take-home

---

## Document Checklist (Auto-Generated)

The system automatically generates a list of supporting documents based on what client enters:

**Examples:**
- Add employer → P60/PAYE certificate required
- Add rental property → Tenancy agreement + bank statements + (loan interest cert if applicable)
- Add dividends → Dividend certificates required
- Enter life insurance premium → Premium certificate required
- 2026 children entered → Birth certificates required
- Mortgage interest entered → Mortgage statement OR rental contract required

This drives the document upload requirements for your client portal.

---

## Status Workflow

```
[Draft] → [Pending Review] → [Reviewed] → [Filed]
   ↑          ↑                   ↑           ↑
Client     Submitted to you    You verified   Filed via
fills in   for verification    & approved     TaxisNet/TFA
```

When integrated with Supabase (Stage 3), this status drives which clients appear in your "review queue" dashboard.

---

## What's Coming Next

### **Stage 3: Supabase Integration**
- Save tax returns per client
- Retrieve historical returns
- Auto-import losses brought forward from prior year
- Document storage with Supabase Storage
- Client portal authentication
- Admin dashboard showing all client returns

### **Stage 4: Greek Translation**
- Full Greek language toggle
- Greek field labels matching TD1 form
- Greek PDF/CSV exports
- Greek email templates

---

## Customization Points

### Update Brand Details
Search for these strings in the file:
```
'PC Prime & Calculate Consultants Ltd'
'Panayiotis Savvas'
'Professional Accountant (SA)'
'+357 96 332 274'
'panayiotis@primeandcalculate.com'
```

### Add Future Tax Years
1. Find the `TAX_YEARS` constant
2. Add a new year object following the same structure
3. Update the year selector arrays in both modes

### Replace Logo
The logo is in `const FIRM_LOGO = "data:image/png;base64,..."`. Replace with your new base64-encoded image.

---

## Verification Status

✓ **Syntax validated** with Babel JSX parser (3,327 lines)
✓ **Calculation engine** verified against Cyprus MOF official calculator
✓ **2025 + 2026** tax rates implemented per official law
✓ **15 Parts** mirroring official TD1 structure
✓ **Array-based** architecture supports unlimited income sources
✓ **Auto-generated** document checklist
✓ **Live computation** with real-time updates

---

*Stage 2 Complete · Ready for client portal integration*
*Prepared for PC Prime & Calculate Consultants Ltd*
